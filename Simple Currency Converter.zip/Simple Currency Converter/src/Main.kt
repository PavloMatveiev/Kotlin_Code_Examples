import java.util.Scanner

// Class to perform currency conversion using predefined exchange rates
class CurrencyConverter(private val rates: Map<String, Double>) {

    fun convert(amount: Double, fromCurrency: String, toCurrency: String): Double? {
        val baseRate = rates[fromCurrency]
        val targetRate = rates[toCurrency]
        if (baseRate == null || targetRate == null) {
            println("Invalid currency code.")
            return null
        }
        return (amount / baseRate) * targetRate
    }
}

fun main() {
    // Map of currency codes to their respective rates compared to USD
    val rates = mapOf(
        "USD" to 1.0,
        "EUR" to 0.93,
        "GBP" to 0.82,
        "JPY" to 134.25,
        "INR" to 77.53
    )

    // Instance of CurrencyConverter initialized with predefined rates
    val converter = CurrencyConverter(rates)
    val scanner = Scanner(System.`in`)

    // Loop to handle user input and perform conversion until the user decides to exit
    while (true) {
        println("Enter the amount followed by the source and target currencies (e.g., 100 USD EUR), or 'exit' to quit:")
        val input = scanner.nextLine()

        // Check for exit command
        if (input.lowercase() == "exit") {
            println("Exiting...")
            break
        }

        val parts = input.split(" ")
        if (parts.size != 3) {
            println("Invalid input format. Please use the format: amount fromCurrency toCurrency")
            continue
        }

        try {
            val amount = parts[0].toDouble()  // Parse the amount to convert
            val fromCurrency = parts[1].uppercase()  // Normalize currency code to uppercase
            val toCurrency = parts[2].uppercase()

            // Perform the currency conversion
            val result = converter.convert(amount, fromCurrency, toCurrency)
            if (result != null) {
                println("$amount $fromCurrency is approximately ${"%.2f".format(result)} $toCurrency")
            }
        } catch (e: NumberFormatException) {
            println("Please enter a valid numeric amount.")
        }
    }
}
