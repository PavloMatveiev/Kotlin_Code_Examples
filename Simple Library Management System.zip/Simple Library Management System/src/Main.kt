// Defines a data class to represent a book with title, author, and year of publication.
class Book(val title: String, val author: String, val year: Int)

// Defines a class that represents a library which can store multiple books.
class Library {
    // A mutable list to hold the collection of books.
    private val books: MutableList<Book> = mutableListOf()

    // Adds a book to the library and prints a confirmation message.
    fun addBook(book: Book) {
        books.add(book)
        println("Book added: ${book.title} by ${book.author}")
    }

    // Removes a book by its title from the library and returns true if successful.
    fun removeBook(title: String): Boolean {
        val bookToRemove = books.find { it.title == title }
        return if (bookToRemove != null) {
            books.remove(bookToRemove)
            println("Book removed: $title")
            true
        } else {
            println("Book not found: $title")
            false
        }
    }

    // Lists all books in the library or indicates if the library is empty.
    fun listBooks() {
        if (books.isEmpty()) {
            println("No books in the library.")
        } else {
            println("Listing books:")
            books.forEach { println("${it.title} by ${it.author}, published in ${it.year}") }
        }
    }
}

// Main function to demonstrate operations in the Library class.
fun main() {
    val library = Library()
    library.addBook(Book("1984", "George Orwell", 1949))
    library.addBook(Book("To Kill a Mockingbird", "Harper Lee", 1960))

    library.listBooks()
    library.removeBook("1984")
    library.listBooks()
}